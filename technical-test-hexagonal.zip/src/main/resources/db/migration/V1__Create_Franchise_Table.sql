create table if not exists franchise (
    id SERIAL,
    name varchar(255),
    constraint franchise_pk primary key (id)
);